<?php
$token = "5636663261:AAFWP-2XqC6_ZS1JywQdOj8ui41qG0SebdE";
require_once ('vendor/autoload.php');
use chillerlan\QRCode\QRCode;

function createQrCode(string $text) {
    return (new QRCode)->render($text);
}

function sendTelegramRequest($method, $data = [])
{
    global $token;

    $url = 'https://api.telegram.org/bot' . $token . '/' . $method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type:multipart/form-data"
    ]);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch,CURLOPT_POSTFIELDS, $data);
    $res = curl_exec($ch);

    echo $res;
}

function sendTelegramPhoto($chatId, $text, $photo) {
    $requestBody = [
        'chat_id' => $chatId,
        'caption' => $text,
        'photo' => new CURLFile($photo)
    ];


    sendTelegramRequest('sendPhoto', $requestBody);
}