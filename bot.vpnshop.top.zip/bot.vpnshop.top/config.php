<?php

//-------------------------
// Dev : @DevMrAmir
// Channel : @AlaCode
//-------------------------

//------- Sql DataBase -------
$serverName = "localhost"; // ادیت نشود
$db_name    = "0"; // نام دیتابیس
$db_user    = "0"; // یوزر دیتابیس
$db_pass    = "0"; // پسورد دیتابیس

$conn = mysqli_connect($serverName, $db_user, $db_pass, $db_name);

if(!$conn){

    die('failed ' . mysqli_connect_error());
}
//------- Data -------
$token        = "0"; // توکن ربات
$admin        = "0"; // عددی ادمین
$vpnname      = "الا وی پی ان"; // اسم شرکت
$bot_id       = "AlaVpnBot"; //ایدی ربات
$tronW        = "تست"; // کیف پول ترون
$cart         = "تست"; // شماره کارت
$chanSef      = "-1001659798195";
$MerchantID   = "0"; // مرچند زرین پال
$web          = "https://site.xyz/vpnPro"; // ادرس پوشه ربات
$domainss     = "@w0l4i.ir";
$subDpmain    = "@dl.w0l4i.ir";
// --- سرور برای اکانت تست
$ip_test      = "5.75.206.64"; // ایپی پنل
$port_test    = "2052"; // پورت سرور
$user_test    = "w0l4i"; // یوزر نیم
$pass_test    = "https://0.xyz/vpnPro/serverTest.txt"; // ادرس فایل کوکی
$port_sazh    = 80; // پورتی که بسازه
$doman_test   = "w0l4i.ir"; // دامنه
$public_test  = "/root/ssl/cert.crt";
$privet_test  = "/root/ssl/private.key";
// Vmess
$ip_vmess     = "65.108.54.245";
$user_vmess   = "w0l4i";
$port_vmess   = "2052";
$pass_vmess   = "https://0.xyz/vpnPro/server2.txt";
$poerS_vmess  = "80";
$doman_vmess  = "dl2.w0l4i.ir";
$public_vmess = "/root/ssl/cert.crt";
$privet_vmess = "/root/ssl/private.key";

// -------
$domainss2     = "w0l4i.ir";
$subDpmain2    = "dl2.w0l4i.ir";
// -------
$domainss3     = "w0l4i.ir";
$subDpmain3    = "test.w0l4i.ir";

$sql2    = "SELECT `chanel` FROM `Settings`";
$result2 = mysqli_query($conn,$sql2);
$res2 = mysqli_fetch_assoc($result2);
$channel_bot  = $res2['chanel'];
//------- Function -------
    
    function bot($method, $user = []){
        global $token;
    $url = "https://api.telegram.org/bot$token"."/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $user);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}

?>